#!/bin/bash
#
# jt工具安装脚本
# 用于在新系统上快速部署视频截图上传工具
#

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

# 安装目标
INSTALL_DIR="/usr/local/bin"
SCRIPTS=("jt" "jtpz" "screenshot-upload")

# 打印函数
print_header() {
    echo -e "\n${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}  $1${NC}"
    echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# 检查是否以root运行
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "此脚本需要root权限运行"
        echo "请使用: sudo $0"
        exit 1
    fi
}

# 检查依赖
check_dependencies() {
    print_header "检查系统依赖"

    local missing_deps=()

    # 必需依赖
    local required_deps=("ffmpeg" "mediainfo" "curl")
    for dep in "${required_deps[@]}"; do
        if command -v "$dep" &>/dev/null; then
            print_success "$dep 已安装"
        else
            print_warning "$dep 未安装"
            missing_deps+=("$dep")
        fi
    done

    # 可选依赖
    if command -v convert &>/dev/null; then
        print_success "imagemagick 已安装 (图片压缩)"
    elif command -v gm &>/dev/null; then
        print_success "graphicsmagick 已安装 (图片压缩)"
    else
        print_warning "imagemagick/graphicsmagick 未安装 (图片压缩功能将不可用)"
    fi

    if command -v jq &>/dev/null; then
        print_success "jq 已安装 (JSON解析)"
    else
        print_warning "jq 未安装 (将使用grep作为替代)"
    fi

    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        echo ""
        print_error "缺少必需依赖: ${missing_deps[*]}"
        echo ""
        echo "请根据你的系统安装依赖："
        echo ""
        echo "Ubuntu/Debian:"
        echo "  sudo apt update && sudo apt install -y ffmpeg mediainfo curl imagemagick jq"
        echo ""
        echo "CentOS/RHEL:"
        echo "  sudo yum install -y epel-release"
        echo "  sudo yum install -y ffmpeg mediainfo curl ImageMagick jq"
        echo ""
        echo "Arch Linux:"
        echo "  sudo pacman -S ffmpeg mediainfo curl imagemagick jq"
        echo ""
        read -p "是否继续安装（缺少依赖将导致功能不可用）？ [y/N] " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# 安装脚本
install_scripts() {
    print_header "安装工具脚本"

    local script_dir="$(cd "$(dirname "$0")" && pwd)/bin"

    for script in "${SCRIPTS[@]}"; do
        local source="${script_dir}/${script}"
        local target="${INSTALL_DIR}/${script}"

        if [[ ! -f "$source" ]]; then
            print_error "找不到脚本: $script"
            continue
        fi

        # 备份已存在的文件
        if [[ -f "$target" ]]; then
            print_info "备份已存在的 $script"
            cp "$target" "${target}.backup.$(date +%Y%m%d%H%M%S)"
        fi

        # 复制并设置权限
        cp "$source" "$target"
        chmod +x "$target"

        if [[ -f "$target" ]]; then
            print_success "已安装: $script -> $target"
        else
            print_error "安装失败: $script"
        fi
    done
}

# 测试安装
test_installation() {
    print_header "测试安装"

    local all_ok=true

    for script in "${SCRIPTS[@]}"; do
        if [[ -x "${INSTALL_DIR}/${script}" ]]; then
            print_success "${script} 可执行"
        else
            print_error "${script} 不可执行或不存在"
            all_ok=false
        fi
    done

    if $all_ok; then
        echo ""
        print_success "所有工具安装成功！"
    else
        echo ""
        print_error "部分工具安装失败，请检查"
    fi
}

# 显示使用说明
show_usage() {
    print_header "使用说明"

    echo -e "${BOLD}1. jt - 视频截图上传命令${NC}"
    echo "   用法："
    echo "     jt                    # 截图当前目录最大视频"
    echo "     jt video.mkv          # 截图指定文件"
    echo "     jt /path/to/dir/      # 截图指定目录最大视频"
    echo ""

    echo -e "${BOLD}2. jtpz - 配置工具${NC}"
    echo "   用法："
    echo "     jtpz                  # 显示当前配置"
    echo "     jtpz -e               # 进入编辑模式"
    echo "     jtpz -q               # 快速配置模式"
    echo "     jtpz -h               # 显示帮助"
    echo ""

    echo -e "${BOLD}3. 首次使用建议${NC}"
    echo "   运行 'jtpz -q' 进行快速配置，设置图床和截图参数"
    echo ""
}

# 卸载功能
uninstall() {
    print_header "卸载 jt 工具"

    read -p "确定要卸载所有工具吗？ [y/N] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "已取消卸载"
        exit 0
    fi

    for script in "${SCRIPTS[@]}"; do
        local target="${INSTALL_DIR}/${script}"
        if [[ -f "$target" ]]; then
            rm -f "$target"
            print_success "已删除: $script"
        fi
    done

    # 删除配置目录（可选）
    local config_dir="$HOME/.config/jt"
    if [[ -d "$config_dir" ]]; then
        read -p "是否删除配置目录 $config_dir ？ [y/N] " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$config_dir"
            print_success "已删除配置目录"
        fi
    fi

    print_success "卸载完成"
}

# 主程序
main() {
    echo -e "${CYAN}${BOLD}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  jt 工具安装程序"
    echo "  视频截图上传工具 v1.0"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${NC}"

    # 处理参数
    case "${1:-}" in
        --uninstall|-u)
            check_root
            uninstall
            exit 0
            ;;
        --help|-h)
            echo "用法: $0 [选项]"
            echo ""
            echo "选项："
            echo "  (无参数)        安装工具"
            echo "  -u, --uninstall 卸载工具"
            echo "  -h, --help      显示帮助"
            exit 0
            ;;
    esac

    # 检查权限
    check_root

    # 检查依赖
    check_dependencies

    # 安装脚本
    install_scripts

    # 测试安装
    test_installation

    # 显示使用说明
    show_usage

    echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}  安装完成！运行 'jtpz -q' 开始配置${NC}"
    echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# 执行主程序
main "$@"
