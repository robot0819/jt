# jt 工具 - 视频截图上传工具包

快速、便捷的视频截图上传工具，支持自动截图、压缩、上传图床和生成 MediaInfo。

## 📦 包含工具

- **jt**: 视频截图上传快捷命令
- **jtpz**: 配置工具，交互式配置图床和截图参数
- **screenshot-upload**: 主脚本，处理视频截图和上传

## 🔧 系统要求

### 必需依赖

- **ffmpeg**: 视频处理和截图
- **mediainfo**: 生成媒体信息
- **curl**: 上传图片到图床

### 可选依赖（建议安装）

- **imagemagick** 或 **graphicsmagick**: 图片压缩功能
- **jq**: JSON 解析（提升性能，否则使用 grep）

### 支持的系统

- Ubuntu / Debian
- CentOS / RHEL
- Arch Linux
- 其他 Linux 发行版（需要自行安装依赖）

## 📥 安装方法

### 1. 解压部署包

```bash
tar -xzf jt-tools-deploy.tar.gz
cd jt-tools-deploy
```

### 2. 安装依赖

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install -y ffmpeg mediainfo curl imagemagick jq
```

**CentOS/RHEL:**
```bash
sudo yum install -y epel-release
sudo yum install -y ffmpeg mediainfo curl ImageMagick jq
```

**Arch Linux:**
```bash
sudo pacman -S ffmpeg mediainfo curl imagemagick jq
```

### 3. 运行安装脚本

```bash
sudo ./install.sh
```

安装脚本会：
- 检查系统依赖
- 将工具安装到 `/usr/local/bin/`
- 验证安装是否成功
- 显示使用说明

## 🚀 快速开始

### 1. 首次配置

运行快速配置向导：
```bash
jtpz -q
```

选择图床类型和截图参数。推荐使用 Pixhost（免费，无需配置）。

### 2. 基本使用

```bash
# 截图当前目录最大视频文件
jt

# 截图指定视频文件
jt video.mkv

# 截图指定目录的最大视频文件
jt /path/to/directory/
```

### 3. 查看配置

```bash
# 查看当前配置
jtpz

# 进入编辑模式修改配置
jtpz -e

# 查看帮助
jtpz -h
```

## 📖 详细用法

### jt 命令

`jt` 是主要的截图上传命令。

**语法：**
```bash
jt [视频文件或目录]
```

**示例：**
```bash
# 处理当前目录
jt

# 处理指定文件
jt /home/user/videos/movie.mkv

# 处理目录（自动选择最大视频）
jt /home/user/videos/
```

**输出：**
- 截图保存在 `~/screenshots/` 目录（可配置）
- 生成 MediaInfo 文本文件
- 图片自动上传到配置的图床
- 显示图片 URL

### jtpz 配置工具

`jtpz` 用于配置截图和上传参数。

**选项：**
```bash
jtpz          # 显示当前配置
jtpz -e       # 进入编辑模式（交互式）
jtpz -q       # 快速配置模式
jtpz -h       # 显示帮助
```

**可配置项：**

1. **图床设置**
   - Pixhost（免费，无需配置，推荐）
   - Chevereto（自建图床，需要 API）

2. **截图参数**
   - 截图数量（3-12 张）
   - 图片质量（1-100）
   - 是否启用压缩

3. **输出目录**
   - 自定义截图保存位置

### screenshot-upload 脚本

这是底层主脚本，通常通过 `jt` 命令调用。也可以直接使用：

```bash
screenshot-upload /path/to/video.mkv
```

## ⚙️ 配置文件

### 主配置

配置通过 `jtpz` 工具修改，保存在：
- 主脚本：`/usr/local/bin/screenshot-upload`
- 用户配置：`~/.config/jt/config.conf`

### 高级配置

如需更精细的控制，可以直接编辑主脚本：
```bash
sudo nano /usr/local/bin/screenshot-upload
```

可配置项包括：
- 图床 API 地址和密钥
- 截图时间戳策略（动态/固定百分比）
- 图片压缩参数
- 重试次数和延迟
- 输出格式

## 🌐 支持的图床

### 1. Pixhost（推荐）

- **优点**: 免费、稳定、无需配置、无限制
- **缺点**: 境外服务器，可能受网络影响
- **配置**: 无需配置，选择即用

### 2. Chevereto

- **优点**: 自建图床，完全控制，隐私安全
- **缺点**: 需要自己搭建服务器
- **配置**: 需要提供 API URL 和 API Key

```bash
jtpz -e  # 进入编辑模式
# 选择 Chevereto
# 输入 API 地址: https://your-image-host.com/api/1/upload
# 输入 API 密钥: your-api-key-here
```

## 🔍 故障排查

### 1. 找不到命令

**问题**: `bash: jt: command not found`

**解决**:
```bash
# 检查是否安装
ls -l /usr/local/bin/jt

# 检查 PATH
echo $PATH | grep "/usr/local/bin"

# 重新安装
cd jt-tools-deploy
sudo ./install.sh
```

### 2. 依赖缺失

**问题**: `错误: 缺少必需依赖`

**解决**: 根据提示安装缺失的依赖。参考上面的"安装依赖"部分。

### 3. 上传失败

**问题**: 截图成功但上传失败

**可能原因**:
- 网络连接问题
- 图床服务不可用
- API 配置错误（Chevereto）

**解决**:
```bash
# 检查网络
curl -I https://api.pixhost.to

# 检查配置
jtpz

# 尝试更换图床
jtpz -e
```

### 4. 图片压缩不工作

**问题**: 压缩功能无效

**原因**: 缺少 ImageMagick 或 GraphicsMagick

**解决**:
```bash
# Ubuntu/Debian
sudo apt install imagemagick

# 或使用 GraphicsMagick
sudo apt install graphicsmagick
```

## 📁 文件结构

```
jt-tools-deploy/
├── bin/
│   ├── jt                    # 快捷命令
│   ├── jtpz                  # 配置工具
│   └── screenshot-upload     # 主脚本
├── docs/
│   └── README.md            # 本文档
└── install.sh               # 安装脚本
```

## 🗑️ 卸载

```bash
cd jt-tools-deploy
sudo ./install.sh --uninstall
```

这会：
- 删除所有安装的工具
- 可选：删除配置目录 `~/.config/jt/`

## 📝 版本信息

- **版本**: v1.0-portable
- **发布日期**: 2026-01-14
- **兼容性**: Linux (Bash 4.0+)

## 🤝 技术支持

如遇问题：

1. 查看本 README 的故障排查部分
2. 检查系统依赖是否完整安装
3. 查看详细错误信息（使用 `-v` 或 `--verbose` 参数）

## 📄 许可证

本工具基于开源脚本优化和封装，供个人和学习使用。

## 🎯 使用场景

- PT 站点发布资源时需要截图
- 视频分享需要预览图
- 媒体库管理和预览
- 批量视频截图和归档
- 自动化视频处理流程

## ⚡ 性能提示

- 使用 SSD 存储提升截图速度
- 网络良好时上传更快
- 启用图片压缩可减少上传时间
- 调整截图数量平衡质量和速度

## 📌 注意事项

1. 首次使用务必运行 `jtpz -q` 进行配置
2. 确保有足够的磁盘空间存储截图
3. 部分图床可能有地区限制
4. 建议定期清理 `~/screenshots/` 目录
5. 自建图床需要确保 API 可访问性

---

**祝使用愉快！** 🎉
